#pragma once

typedef class Title
{
private:
	int mouse_x, mouse_y;

public:
	Title();
	~Title(){};

	void Title_Graph_Load();
	void Title_Screen();
}TITLE;