#pragma once
#include "DxLib.h"

typedef class KeyInput
{
private:

public:
	bool Key_isPush(int Key_type, bool debug);

}KEY_INPUT;