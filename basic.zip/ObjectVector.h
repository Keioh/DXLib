#pragma once

class Vector2
{
private:

public:
	int x;
	int y;
};

class Vector2F
{
private:

public:
	float x;
	float y;
};

class Vector3
{
private:

public:
	int x;
	int y;
	int z;
};

class Vector3F
{
private:

public:
	float x;
	float y;
	float z;
};

class window
{
private:

public:
	int x;
	int y;
	int bit;
};