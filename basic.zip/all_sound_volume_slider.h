#pragma once
#include "button_ui.h"


class AllSoundVolumeSlider
{
private:

public:
	AllSoundVolumeSlider();

	ButtonUI all_sound_volume_slider;

	void init();
	void LoadGraphics();

	int DrawAllSoundVolumeSlider(int x, int y, unsigned char color, bool wire);

};